// Nama  : Riski Midi Wardana
// Nim   : 123170035
// Kelas : C

package com.example.projectakhir.presenter;

public interface MainInterface {
    void getAllItem();
    void getItemById(String id);
    void updateItem(String id, String name, String description);
    void deleteItem(String id);
    void createItem(String name, String description);
}
