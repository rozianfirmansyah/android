// Nama  : Riski Midi Wardana
// Nim   : 123170035
// Kelas : C

package com.example.projectakhir.presenter;

import com.example.projectakhir.model.GetItemResponse;
import com.example.projectakhir.model.GetItemsResponse;
import com.example.projectakhir.model.PostItemResponse;
import com.example.projectakhir.remote.BaseApp;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainPresenter implements MainInterface {
    private MainView mainView;

    public MainPresenter(MainView mainView) {
        this.mainView = mainView;
    }

    @Override
    public void getAllItem() {
        BaseApp.service.getAllItems().enqueue(new Callback<GetItemsResponse>() {
            @Override
            public void onResponse(Call<GetItemsResponse> call,
                               Response<GetItemsResponse> response) {

                if (response.isSuccessful())
                    mainView.getAllSuccess(response.body());
                else
                    mainView.onError(response.message());
            }

            @Override
            public void onFailure(Call<GetItemsResponse> call, Throwable t) {
                mainView.onFailure(t.getMessage());
            }
        });
    }

    @Override
    public void getItemById(String id) {
        BaseApp.service.getItemById(id).enqueue(new Callback<GetItemResponse>() {
            @Override
            public void onResponse(Call<GetItemResponse> call, Response<GetItemResponse> response) {
                if(response.isSuccessful()) {
                    mainView.getByIdSuccess(response.body());
                }else {
                    mainView.onError(response.message());
                }
            }

            @Override
            public void onFailure(Call<GetItemResponse> call, Throwable t) {
                mainView.onFailure(t.getMessage());
            }
        });
    }

    @Override
    public void updateItem(String id, String name, String description) {
        BaseApp.service.updateDataItems(id, name, description).enqueue(new
            Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful())
                    mainView.setToast(response.message());
                else
                    mainView.onError(response.message());
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                mainView.onFailure(t.getMessage());
            }
        });
    }

    @Override
    public void deleteItem(String id) {
        BaseApp.service.deleteDataItems(id).enqueue(new
            Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject>
                    response) {
                if (response.isSuccessful())
                    mainView.setToast(response.message());
                else
                    mainView.onError(response.message());
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                mainView.onFailure(t.getMessage());
            }
        });
    }

    @Override
    public void createItem(String name, String description) {
        BaseApp.service.createItems(name, description).enqueue(new Callback<PostItemResponse>() {
            @Override
            public void onResponse(Call<PostItemResponse> call, Response<PostItemResponse> response) {

                if (response.isSuccessful())
                    mainView.setToast(response.message());
                else
                    mainView.onError(response.message());
            }

            @Override
            public void onFailure(Call<PostItemResponse> call, Throwable t) {
                mainView.onFailure(t.getMessage());
            }
        });
    }
}
