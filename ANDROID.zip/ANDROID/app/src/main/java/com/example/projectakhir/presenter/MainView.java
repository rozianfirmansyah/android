// Nama  : Riski Midi Wardana
// Nim   : 123170035
// Kelas : C

package com.example.projectakhir.presenter;

import com.example.projectakhir.model.GetItemResponse;
import com.example.projectakhir.model.GetItemsResponse;

public interface MainView {
    void getAllSuccess(GetItemsResponse list);
    void getByIdSuccess(GetItemResponse data);
    void setToast(String message);
    void onError(String errorMessage);
    void onFailure(String failureMessage);
}
