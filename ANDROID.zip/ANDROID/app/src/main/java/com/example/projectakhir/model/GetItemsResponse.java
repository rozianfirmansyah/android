// Nama  : Riski Midi Wardana
// Nim   : 123170035
// Kelas : C

package com.example.projectakhir.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetItemsResponse {

	@SerializedName("data")
	private List<Item> data;

	@SerializedName("errors")
	private Object errors;

	public void setData(List<Item> data){
		this.data = data;
	}

	public List<Item> getData(){
		return data;
	}

	public void setErrors(Object errors){
		this.errors = errors;
	}

	public Object getErrors(){
		return errors;
	}

	@Override
 	public String toString(){
		return 
			"GetItemsResponse{" +
			"data = '" + data + '\'' + 
			",errors = '" + errors + '\'' + 
			"}";
		}
}