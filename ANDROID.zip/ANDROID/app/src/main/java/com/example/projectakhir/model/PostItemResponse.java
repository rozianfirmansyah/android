// Nama  : Riski Midi Wardana
// Nim   : 123170035
// Kelas : C

package com.example.projectakhir.model;

import com.google.gson.annotations.SerializedName;

public class PostItemResponse {

	@SerializedName("data")
	private Item data;

	@SerializedName("errors")
	private Object errors;

	public void setData(Item data){
		this.data = data;
	}

	public Item getData(){
		return data;
	}

	public void setErrors(Object errors){
		this.errors = errors;
	}

	public Object getErrors(){
		return errors;
	}

	@Override
 	public String toString(){
		return 
			"PostItemResponse{" +
			"data = '" + data + '\'' + 
			",errors = '" + errors + '\'' + 
			"}";
		}
}